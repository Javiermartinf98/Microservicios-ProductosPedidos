package com.curso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.curso.dao.ProductosDao;
import com.curso.model.Producto;

@Service
public class ProductosServiceImpl implements ProductosService 
{
	@Autowired
	ProductosDao dao;
	
	@Override
	public List<Producto> verProductos() 
	{
		return dao.findAll();
	}

	@Override
	public double precioProducto(int codproducto) 
	{
		Producto producto=dao.findById(codproducto).orElse(null);
		
		return producto!=null?producto.getPrecioUnitario():0;
	}

	@Override
	public void actualizarStock(int codproducto, int unidades)
	{
		Producto producto=dao.findById(codproducto).orElse(null);
		
		if(producto!=null && producto.getStock()>unidades)
		{
			producto.setStock(producto.getStock()-unidades);
			dao.save(producto);
		}
	}
}
