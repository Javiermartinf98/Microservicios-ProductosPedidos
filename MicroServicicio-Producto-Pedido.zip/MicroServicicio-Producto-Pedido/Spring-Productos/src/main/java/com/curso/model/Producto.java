package com.curso.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="productos")
public class Producto 
{
	@Id
	private int codproducto;
	private String nombre;
	private double preciounitario;
	private int stock;
	
	public Producto() {}

	public Producto(int codproducto, String nombre, double preciounitario, int stock)
	{
		this.codproducto = codproducto;
		this.nombre = nombre;
		this.preciounitario = preciounitario;
		this.stock = stock;
	}

	public int getCodProducto() {
		return codproducto;
	}
	public void setCodProducto(int codproducto) {
		this.codproducto = codproducto;
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPrecioUnitario() {
		return preciounitario;
	}
	public void setPrecioUnitario(double preciounitario) 
	{
		this.preciounitario = preciounitario;
	}

	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
}
