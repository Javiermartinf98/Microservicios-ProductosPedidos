package com.curso.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.curso.dao.PedidosDao;
import com.curso.model.Pedido;
import com.curso.model.Producto;

@Service
public class PedidosServiceImpl implements PedidosService 
{
	@Autowired
	PedidosDao dao;
	
	@Autowired
	RestTemplate template;
	private String url="http://localhost:8600/";
	
	@Override
	public List<Pedido> verPedidos() 
	{
		return dao.findAll();
	}

	
	@Override
	public void insertarPedido(Pedido pedido) 
	{
		pedido.setFechaPedido(new Date());
		
		pedido.setTotal(pedido.getUnidades()*obtenerPrecio(pedido.getCodigoProducto()));
		dao.save(pedido);
		
		actualizarStock(pedido.getCodigoProducto(),pedido.getUnidades());
	}
	
	private double obtenerPrecio(int codigoProducto) 
	{
		return Double.parseDouble(template.getForObject(url+"precio/{codigo}", String.class,codigoProducto));
	}
	
	private void actualizarStock(int codigoProducto, int unidades)
	{
		template.put(url+"producto/{codigo}/{unidades}", null, codigoProducto,unidades);
	}

}
