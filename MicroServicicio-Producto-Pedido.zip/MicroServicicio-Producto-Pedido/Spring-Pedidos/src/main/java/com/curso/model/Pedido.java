package com.curso.model;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="pedidos")
public class Pedido 
{
	@Id
	private int idpedido;
	private int codproducto;
	private int unidades;
	private double total;
	private Date fechapedido;
	
	public Pedido() {}

	public Pedido(int idpedido, int codproducto, int unidades, double total, Date fechapedido)
	{
		this.idpedido = idpedido;
		this.codproducto = codproducto;
		this.unidades = unidades;
		this.total = total;
		this.fechapedido = fechapedido;
	}

	public int getIdPedido() {
		return idpedido;
	}
	public void setIdPedido(int idpedido) {
		this.idpedido = idpedido;
	}
	
	public int getCodigoProducto() {
		return codproducto;
	}
	public void setCodigoProducto(int codproducto) {
		this.codproducto = codproducto;
	}
	
	public int getUnidades() {
		return unidades;
	}
	public void setUnidades(int unidades) {
		this.unidades = unidades;
	}
	
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	
	public Date getFechaPedido() {
		return fechapedido;
	}
	public void setFechaPedido(Date fechapedido) {
		this.fechapedido = fechapedido;
	}
}
